import { TipoPregunta } from './tipo-pregunta';

describe('TipoPregunta', () => {
  it('should create an instance', () => {
    expect(new TipoPregunta()).toBeTruthy();
  });
});
