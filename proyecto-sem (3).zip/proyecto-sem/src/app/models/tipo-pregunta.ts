export class TipoPregunta {
}
