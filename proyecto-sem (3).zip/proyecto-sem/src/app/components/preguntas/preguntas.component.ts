import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

interface Pregunta {
  id: number;
  texto: string;
  tipo: 'abierta' | 'cerrada' | 'multiple';
  opciones?: string[];
  editando: boolean;
}

@Component({
  selector: 'app-preguntas',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './preguntas.component.html',
  styleUrl: './preguntas.component.sass'
})
export class PreguntasComponent implements OnInit {
  preguntas: Pregunta[] = [];
  nuevaPregunta: string = '';
  nuevoTipo: 'abierta' | 'cerrada' | 'multiple' = 'abierta';
  nuevasOpciones: string = '';
  
  ngOnInit() {
    this.preguntas = [
      { 
        id: 1, 
        texto: '¿Con qué frecuencia utilizas tecnología en tu educación diaria?', 
        tipo: 'multiple',
        opciones: ['Nunca', 'Rara vez', 'Algunas veces', 'Frecuentemente', 'Siempre'],
        editando: false 
      },
      { 
        id: 2, 
        texto: '¿Qué dispositivos utilizas más para aprender? Explica por qué.', 
        tipo: 'abierta',
        editando: false 
      },
      { 
        id: 3, 
        texto: '¿Consideras que el uso de la tecnología mejora tu aprendizaje?', 
        tipo: 'cerrada',
        editando: false 
      },
      { 
        id: 4, 
        texto: '¿Qué plataformas educativas prefieres?', 
        tipo: 'multiple',
        opciones: ['Google Classroom', 'Moodle', 'Canvas', 'Microsoft Teams', 'Otra'],
        editando: false 
      },
      { 
        id: 5, 
        texto: '¿Cuántas horas dedicas al estudio en línea?', 
        tipo: 'multiple',
        opciones: ['Menos de 1 hora', '1-2 horas', '2-4 horas', 'Más de 4 horas'],
        editando: false 
      }
    ];
  }

  agregarPregunta() {
    if (this.nuevaPregunta.trim()) {
      const nuevaId = this.preguntas.length ? Math.max(...this.preguntas.map(p => p.id)) + 1 : 1;
      const nuevaPregunta: Pregunta = {
        id: nuevaId,
        texto: this.nuevaPregunta,
        tipo: this.nuevoTipo,
        editando: false
      };

      if (this.nuevoTipo === 'multiple' && this.nuevasOpciones.trim()) {
        nuevaPregunta.opciones = this.nuevasOpciones.split(',').map(opt => opt.trim());
      }

      this.preguntas.push(nuevaPregunta);
      this.limpiarFormulario();
    }
  }

  limpiarFormulario() {
    this.nuevaPregunta = '';
    this.nuevoTipo = 'abierta';
    this.nuevasOpciones = '';
  }

  editarPregunta(pregunta: Pregunta) {
    pregunta.editando = true;
    if (pregunta.tipo === 'multiple' && pregunta.opciones) {
      this.nuevasOpciones = pregunta.opciones.join(', ');
    }
  }

  guardarEdicion(pregunta: Pregunta) {
    if (pregunta.texto.trim()) {
      if (pregunta.tipo === 'multiple' && this.nuevasOpciones.trim()) {
        pregunta.opciones = this.nuevasOpciones.split(',').map(opt => opt.trim());
      }
      pregunta.editando = false;
      this.nuevasOpciones = '';
    }
  }

  eliminarPregunta(id: number) {
    this.preguntas = this.preguntas.filter(p => p.id !== id);
  }

  cancelarEdicion(pregunta: Pregunta, textoOriginal: string, tipoOriginal: 'abierta' | 'cerrada' | 'multiple') {
    pregunta.texto = textoOriginal;
    pregunta.tipo = tipoOriginal;
    pregunta.editando = false;
    this.nuevasOpciones = '';
  }
}