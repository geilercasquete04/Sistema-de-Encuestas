import { Component } from '@angular/core';

@Component({
  selector: 'app-form-login',
  standalone: true,
  imports: [],
  templateUrl: './form-login.component.html',
  styleUrl: './form-login.component.sass'
})
export class FormLoginComponent {

}
