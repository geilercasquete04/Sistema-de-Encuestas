// encuestas.component.ts
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

interface Encuesta {
  id: number;
  nombre: string;
  fechaCreacion: string;
}

interface EncuestaEdicion {
  id: number;
  nombre: string;
  fechaCreacion: string;
}

@Component({
  selector: 'app-encuestas',
  standalone: true,
  imports: [RouterLink, CommonModule, FormsModule],
  templateUrl: './encuestas.component.html',
  styleUrl: './encuestas.component.sass'
})
export class EncuestasComponent implements OnInit {
  encuestas: Encuesta[] = [];
  encuestaEnEdicion: EncuestaEdicion | undefined;
  
  readonly defaultEncuestas: Encuesta[] = [
    { id: 1, nombre: 'Acceso a Tecnología en Zonas Rurales', fechaCreacion: '2024-11-01' },
    { id: 2, nombre: 'Uso de Inteligencia Artificial en Educación', fechaCreacion: '2024-11-01' },
    { id: 3, nombre: 'Preferencias en Dispositivos Móviles', fechaCreacion: '2024-11-01' },
    { id: 4, nombre: 'Impacto de las Redes Sociales', fechaCreacion: '2024-11-01' },
    { id: 5, nombre: 'Servicios TIC y Satisfacción del Usuario', fechaCreacion: '2024-11-01' }
  ];

  ngOnInit(): void {
    this.cargarEncuestas();
  }

  cargarEncuestas(): void {
    const storedEncuestas = localStorage.getItem('encuestas');
    if (!storedEncuestas) {
      this.encuestas = [...this.defaultEncuestas];
      localStorage.setItem('encuestas', JSON.stringify(this.encuestas));
    } else {
      this.encuestas = JSON.parse(storedEncuestas);
    }
  }

  editarEncuesta(encuesta: Encuesta): void {
    this.encuestaEnEdicion = {
      id: encuesta.id,
      nombre: encuesta.nombre,
      fechaCreacion: encuesta.fechaCreacion
    };
  }

  guardarEdicion(): void {
    if (!this.encuestaEnEdicion) return;

    const index = this.encuestas.findIndex(e => e.id === this.encuestaEnEdicion?.id);
    if (index !== -1) {
      if (!this.encuestaEnEdicion.nombre.trim()) {
        alert('El nombre de la encuesta no puede estar vacío');
        return;
      }

      if (!this.isValidDate(this.encuestaEnEdicion.fechaCreacion)) {
        alert('Por favor, ingrese una fecha válida');
        return;
      }

      this.encuestas[index] = {
        ...this.encuestaEnEdicion
      };
      
      localStorage.setItem('encuestas', JSON.stringify(this.encuestas));
      this.encuestaEnEdicion = undefined;
    }
  }

  cancelarEdicion(): void {
    this.encuestaEnEdicion = undefined;
  }

  eliminarEncuesta(id: number): void {
    if (confirm('¿Estás seguro de que deseas eliminar esta encuesta?')) {
      this.encuestas = this.encuestas.filter(encuesta => encuesta.id !== id);
      
      if (this.encuestas.length === 0) {
        this.encuestas = [...this.defaultEncuestas];
      }
      
      localStorage.setItem('encuestas', JSON.stringify(this.encuestas));
    }
  }

  agregarEncuesta(): void {
    const nuevoId = Math.max(...this.encuestas.map(e => e.id), 0) + 1;
    const nuevaEncuesta: Encuesta = {
      id: nuevoId,
      nombre: 'Nueva Encuesta',
      fechaCreacion: new Date().toISOString().split('T')[0]
    };
    
    this.encuestas.push(nuevaEncuesta);
    localStorage.setItem('encuestas', JSON.stringify(this.encuestas));
    this.editarEncuesta(nuevaEncuesta);
  }

  private isValidDate(dateString: string): boolean {
    const date = new Date(dateString);
    return date instanceof Date && !isNaN(date.getTime());
  }

  isEncuestaEnEdicion(id: number): boolean {
    return this.encuestaEnEdicion?.id === id;
  }
}