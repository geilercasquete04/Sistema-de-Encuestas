import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-add-encuestas',
  standalone: true,
  imports: [],
  templateUrl: './add-encuestas.component.html',
  styleUrl: './add-encuestas.component.sass'
})
export class AddEncuestasComponent {

}
